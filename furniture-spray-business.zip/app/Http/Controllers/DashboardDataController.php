<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardDataController extends Controller
{
    private $_request = null;
    private $_modal = null;

    /**
     * Create a new controller instance.
     *
     * @return $reauest, $modal
     */
    // public function __construct(Request $request, {{ model }} $modal)
    // {
    //     $this->_request = $request;
    //     $this->_modal = $modal;
    // }
    // public function navbar_pages($slug)
    // {
    //     dd($slug);
    // }

}
