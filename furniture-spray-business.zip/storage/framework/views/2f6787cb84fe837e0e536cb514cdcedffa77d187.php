<div class="deliver-charges py-5">
    <div class="container">
        <table class="table table-bordered nowrap no-footer w-100" id="example">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Total Charges</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($datadetail): ?>
                    <?php $__currentLoopData = $datadetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $datadetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($datadetail->total_charges); ?></td>
                            <td>
                                <div>
                                    <a href="" data-bs-toggle="modal" data-bs-target="#editdeliverycharges"
                                        title="Edit">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/components/pages/delivery.blade.php ENDPATH**/ ?>