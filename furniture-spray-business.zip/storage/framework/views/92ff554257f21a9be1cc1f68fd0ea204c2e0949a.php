<div class="row">
    <div class="col-12 col-md-2">
        <div class="form-group">
            <label for="matt_finish">Rate / Sqm (1 sided) - Matt Finish</label>
            <select name="matt_finish" id="matt_finish" class="form-control " data-live-search="true" tabindex="-1"
                aria-hidden="true">
                <option value="65">
                    Single Side
                </option>
                <option value="130">
                    Double Side
                </option>
            </select>
        </div>
    </div>
    <div class="col-12 col-md-2">
        <div class="form-group">
            <label for="spraying_edges">Spraying Edges - Rate per L/M</label>
            <select name="spraying_edges" id="spraying_edges" class="form-control ">
                <option value="5">
                    Yes
                </option>

            </select>
        </div>
    </div>
    <div class="col-12 col-md-2">
        <div class="form-group">
            <label for="metallic_paint">Metallic Paint - Add on / Sqm (1 sided)s</label>
            <select name="metallic_paint" id="metallic_paint" class="form-control ">
                <option value="5">
                    Single Side
                </option>
                <option value="10">
                    Double Side
                </option>
            </select>
        </div>
    </div>
    <div class="col-12 col-md-2">
        <div class="form-group">
            <label for="80_Gloss">80% Gloss - Add on / Sqm (1 sided)</label>
            <select name="80_Gloss" id="80_Gloss" class="form-select">
                <option value="10">Single Side</option>
                <option value="20">Double Side</option>
            </select>
        </div>
    </div>
    <div class="col-12 col-md-2">
        <div class="form-group">
            <label for="100_Gloss">100% Gloss / Wet Look PU Paint (SQM)</label>
            <select name="100_Gloss" id="100_Gloss" class="form-select">
                <option value="0">No</option>
                <option value="30">Yes</option>
                
            </select>
        </div>
    </div>
    <div class="col-12 col-md-2">
        <div class="form-group">
            <label for="100_Gloss2">100% Gloss / Wet Look Clear Acrylic Lacquer (SQM)</label>
            <select name="100_Gloss2" id="100_Gloss2" class="form-select">
                <option value="0">No</option>
                <option value="45">Yes</option>
                
            </select>
        </div>
    </div>
</div>
<div class="col-sm-2 finish">
    <div class="form-group">
        <label for="edgebanding_rate">Edgebanding - Rate Per L/M</label>
        <select name="edgebanding_rate" id="edgebanding_rate" class="form-control ">
            <option value="0">No</option>
            <option value="6">Yes</option>
        </select>
    </div>
</div>

<div class="col-sm-2 shape">
    <div class="form-group">
        <label for="micro_bevel">Micro bevel - Rate Per L/M</label>
        <select name="micro_bevel" id="micro_bevel" class="form-control ">
            <option value=""> -- Select One --</option>
            <option value="0">No</option>
            <option value="4">Yes</option>
        </select>
    </div>
</div>
<div class="col-sm-2 sand">
    <div class="form-group">
        <label for="routed_j">Routed / J Handle Spraying</label>
        <select name="routed_j" id="routed_j" class="form-control ">
            <option value="0">
                No
            </option>
            <option value="15">
                yes
            </option>
        </select>
    </div>
</div>
<div class="col-sm-2 ritecs">
    <div class="form-group">
        <label for="beaded_door">Beaded Door - Rate Per L/M</label>
        <select name="beaded_door" id="beaded_door" class="form-control ">
            <option value="0">
                No
            </option>
            <option value="14">
                Yes
            </option>

        </select>
    </div>
</div>
<div class="col-sm-2 bevel_edges">
    <div class="form-group">
        <label for="bevel_edges">Bevel Edges</label>
        <select name="bevel_edges" id="bevel_edges" class="form-control ">
            <option value=""> -- Select One --</option>
            <option value="">
                Yes
            </option>
            <option value="">
                No
            </option>
        </select>
    </div>
</div>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/quote/paint.blade.php ENDPATH**/ ?>