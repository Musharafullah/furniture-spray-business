<div class="col-12 col-md-6">
    <div class="form-group">
        <label for="cust-name"><?php echo e($data->name); ?></label>
        <input id="cust-name" name="cust-name" class="form-control" type="text" placeholder="Enter Name" value=""
            readonly="">
    </div>
</div>
<div class="col-12 col-md-6">
    <div class="form-group">
        <label for="cust-phone"><?php echo e($data->phone); ?></label>
        <input id="cust-phone" name="cust-phone" class="form-control" type="number" placeholder="Enter Number"
            readonly="">
    </div>
</div>
<div class="col-12 col-md-6">
    <div class="form-group">
        <label for="cust-email"><?php echo e($data->email); ?></label>
        <input id="cust-email" name="cust-email" class="form-control" type="email" placeholder="Enter Email"
            readonly="">
    </div>
</div>
<div class="col-12 col-md-6">
    <div class="form-group">
        <label for="cust-postcode"><?php echo e($data->postal_code); ?></label>
        <input id="cust-postcode" name="cust-postcode" class="form-control" type="text" placeholder="Postcode"
            readonly="">
    </div>
</div>
<div class="col-12">
    <div class="form-group">
        <label for="cust-address"><?php echo e($data->address); ?></label>
        <textarea id="cust-address" class="form-control" rows="3" placeholder="Enter Address" readonly=""></textarea>
    </div>
</div>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/render_data/clients.blade.php ENDPATH**/ ?>