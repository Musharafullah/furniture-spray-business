<div class="product mt-5">
    <div class="container">
        <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary pull-right">
            <i class="fa fa-plus"></i> Add New Product
        </a>
        <table class="table table-bordered nowrap no-footer w-100" id="example">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Code</th>
                    <th>Title</th>
                    <th width="100">Image</th>
                    <th>Cost From Supplier</th>
                    <th>Sale Net SQM</th>
                    <th>Type</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

                <?php if($datadetail): ?>
                    <?php $__currentLoopData = $datadetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $type = $product->type;
                            $pro_type = str_replace('_', ' ', $type);
                            $pro_type = ucwords($pro_type);
                        ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($product->code); ?></td>
                            <td><?php echo e($product->product_name); ?></td>
                            <td class="text-center">
                                <img src="<?php echo e(asset('product_image/product/' . $product->product_image_path)); ?>">
                            </td>
                            <td><?php echo e($product->cost_from_supplier); ?></td>
                            <td><?php echo e($product->sale_net_sqm); ?></td>
                            <td><?php echo e($pro_type); ?></td>
                            <td>
                                <div>
                                    <a href="<?php echo e(route('product.edit', $product->id)); ?>" data-toggle="tooltip"
                                        title="Edit Product">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    <a href="<?php echo e(route('product_duplicate', $product->id)); ?>" data-toggle="tooltip"
                                        title="Duplicate Product">
                                        <i class="fa fa-copy"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/components/pages/products.blade.php ENDPATH**/ ?>