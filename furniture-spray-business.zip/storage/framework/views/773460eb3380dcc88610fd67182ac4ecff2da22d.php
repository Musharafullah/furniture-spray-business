<div class="row mt-3">
    <div class="col-sm-6">
        <div class="form-group">
            <label for="name">Name</label>
            <?php if($client->name): ?>
                <input id="name" name="name" class="form-control" type="text" placeholder="Enter Name"
                    value="<?php echo e($client->name); ?>">
            <?php else: ?>
                <input id="name" name="name" class="form-control" type="text" placeholder="Enter Name"
                    value="">
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <?php if($errors->has('name')): ?>
                    <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="form-group">
            <label for="phone">Phone</label>
            <?php if($client->phone): ?>
                <input id="phone" name="phone" class="form-control" type="number" placeholder="Enter Phone No"
                    value="<?php echo e($client->phone); ?>">
            <?php else: ?>
                <input id="phone" name="phone" class="form-control" type="number" placeholder="Enter Phone No"
                    value="">
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="form-group">
            <label for="email">Email</label>
            <?php if($client->email): ?>
                <input id="email" name="email" class="form-control" type="email" placeholder="Enter Email"
                    value="<?php echo e($client->email); ?>">
            <?php else: ?>
                <input id="email" name="email" class="form-control" type="email" placeholder="Enter Email"
                    value="">
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <?php if($errors->has('email')): ?>
                    <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="form-group">
            <label for="postal_code">Billing Postcode</label>
            <?php if($client->postal_code): ?>
                <input id="postal_code" name="postal_code" class="form-control" type="text"
                    placeholder="Enter ZipCode" value="<?php echo e($client->postal_code); ?>">
            <?php else: ?>
                <input id="postal_code" name="postal_code" class="form-control" type="text"
                    placeholder="Enter ZipCode" value="">
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <?php if($errors->has('postal_code')): ?>
                    <strong class="text-danger"><?php echo e($errors->first('postal_code')); ?></strong>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <input type="hidden" id="latitude" name="latitude" value="<?php echo e($client->latitude ?? old('latitude')); ?>">
    <input type="hidden" id="longitude" name="longitude" value="<?php echo e($client->longitude ?? old('longitude')); ?>">
    <div class="col-sm-4">
        <div class="form-group">
            <label for="trade_discount">Trade Discount</label>
            <select name="trade_discount" class="form-select">
                <?php
                    $discount = [0, 10, 15, 20, 25, 30, 35, 40, 45, 50];
                ?>
                <option value=""> -- Select Product Type --</option>
                <?php $__currentLoopData = $discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $select = old('trade_discount', $client->trade_discount) == $type ? 'selected' : '';
                    ?>
                    <option value="<?php echo e($type ?? old('trade_discount')); ?>" <?php echo e($select); ?>><?php echo e($type); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->any()): ?>
                <?php if($errors->has('trade_discount')): ?>
                    <strong class="text-danger"><?php echo e($errors->first('trade_discount')); ?></strong>
                <?php endif; ?>
            <?php endif; ?>
            
            </select>
        </div>
    </div>
    <div class="col-12">
        <div class="form-group">
            <label for="address">Address</label>
            <?php if($client->postal_code): ?>
                <textarea name="address" id="address" class="form-control" rows="5"><?php echo e($client->address); ?></textarea>
            <?php else: ?>
                <textarea name="address" id="address" class="form-control" rows="5"></textarea>
            <?php endif; ?>

        </div>
    </div>
</div>
<div class="row d-flex button-container">
    <div class="col-sm-6">
        <button type="submit" class="btn btn-primary-rounded">
            Save <span><i class="fa fa-save"></i></span>
        </button>
    </div>
</div>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/customer/_form.blade.php ENDPATH**/ ?>