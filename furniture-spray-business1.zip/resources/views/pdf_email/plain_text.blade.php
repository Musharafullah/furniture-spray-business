<style type="text/css">
    body,
    td,
    th {
        font-family: verdana;
    }
</style>

<p>Dear Customer,<br /><br>
    Thank you for your recent enquiry. Please find attached our quotation attached. If you have any questions please do
    not hesitate to ask either by replying to this email or by calling our office number on 003 225 405 45.</p>
<p>Depending on your request and options available, you will see different prices in the PDF file. If you want to
    proceed, please feel free to make a payment using the relevant link on the bottom of the quote. <br>
    <br>
    We look forward to receiving your order and any future enquiries you may have. <br><br>
    For more information on the products and services available at ROKA please go to our website at
    www.roka.spraufurniture<br /><br />

    Kind regards <br>
    Roka Team
</p>
