Dear admin, <br /><br />

Client Name: {{ $first_name }} {{ $last_name }}<br />
Quote: <strong> MCG-0000{{ $id }} </strong> Paid the amount of quote <strong> {{ $amount }}</strong><br />
Payment status of quote <strong> MCG-0000{{ $id }} </strong> is {{ $status }}<br />


Please login to your Sagepay and website account for futher information
