<style type="text/css">
.verdana {
	font-family: verdana;
}
body,td,th {
	font-family: verdana;
}
</style>
<p>Hi <strong>{{ $name }}</strong><br />
  
  <br />
  
  I do hope that you were happy with our estimate.<br />
  
  
  
I am just updating our estimate database and would appreciate any feedback on whether the price was acceptable to yourself/your client and when you believe the project may come about.If you have already placed an order, please ignore this email. <br />
  
  
  
  Any additional information is always gratefully received.<br />
  
  
  
  If you would require additional information, then also, please do not hesitate to contact us.<br />
  
  
  
  Many thanks.<br /><br />
  
  
  
  
  
  Kind regards,<br /><br />
  
  
  
  Helen</p>
