<option value="">-- Select Customer --</option>
<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value='<?php echo e($client->id); ?>'><?php echo e($client->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH P:\office project\furniture-spray-business\resources\views/render_data/clients.blade.php ENDPATH**/ ?>