<html>

<head>
    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('title'); ?>
</head>

<body>

    <!----------------------- Header ------------------------------->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <!----------------------- End Header ------------------------------->


    <?php echo $__env->yieldContent('content'); ?>
    <?php if(\Auth::check()): ?>
        <?php
            
            $admin = App\Models\User::where('id', Auth::user()->id)->first();
        ?>

        <!--start Modal for Update admin profile-->
        <div aria-hidden="true" aria-labelledby="EditProfile" class="modal fade" id="updateprofile" role="dialog"
            tabindex="-1" style="margin-top:100px;">
            <div class="modal-dialog" role="document">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form method="POST" action="<?php echo e(route('admin_update')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                                <h3><span id="form_output" class="alert-info"></span></h3>
                                <h6><span id="errors" class="alert-danger"></span></h6>
                                <div class="row">
                                    <div class="col-sm-6">

                                        <h3 class="modal-title">Update Profile</h3>
                                    </div>
                                    <div class="col-sm-6">
                                        <button aria-label="Close" class="close" data-dismiss="modal"
                                            type="button"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="admin-name">Name</label>
                                            <input id="admin-name" name="name" class="form-control" type="text"
                                                placeholder="Enter Name" value="<?php echo e($admin->name); ?>">
                                            <?php if($errors->has('admin-name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong
                                                        class="text-danger"><?php echo e($errors->first('admin-name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="admin-email">Email</label>
                                            <input id="admin-email" name="email" class="form-control" type="email"
                                                placeholder="Enter Email" value="<?php echo e($admin->email); ?>">
                                            <?php if($errors->has('admin-email')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong
                                                        class="text-danger"><?php echo e($errors->first('admin-email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="admin-password">Password</label>
                                            <input id="admin-password" name="password" class="form-control"
                                                type="password" placeholder="Enter Password">
                                            <?php if($errors->has('admin-password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong
                                                        class="text-danger"><?php echo e($errors->first('admin-password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="admin-address">Address</label>
                                            <textarea class="form-control" name="address" rows="5"><?php echo e($admin->address); ?></textarea>
                                            <?php if($errors->has('admin-address')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong
                                                        class="text-danger"><?php echo e($errors->first('admin-address')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    
                                    <button class="btn btn-primary" type="submit" id="edit">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/dashboardlayouts/master.blade.php ENDPATH**/ ?>