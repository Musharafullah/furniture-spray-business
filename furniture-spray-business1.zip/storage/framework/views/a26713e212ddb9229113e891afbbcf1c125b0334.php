<div class="quotes py-5">
    <div class="container">
        <table class="table table-bordered nowrap no-footer w-100" id="example">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Client</th>
                    <th>Phone Number</th>
                    <th>Postal Code</th>
                    <th>Added On</th>
                    <th>Quote Total</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($datadetail): ?>
                    <?php $__currentLoopData = $datadetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>MCG-0000<?php echo e($key + 1); ?></td>
                            <td><?php echo e($quote->client->name); ?></td>
                            <td><?php echo e($quote->client->phone); ?></td>
                            <td><?php echo e($quote->client->postal_code); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($quote->created_at))); ?></td>
                            <td>
                                <?php
                                    $quote_total = $quote->deals->sum('total_gross');
                                ?>
                                <?php echo e($quote_total); ?></td>

                            <td>
                                <select name="status" id="quote-status"
                                    onchange="quoteStatus('<?php echo e($quote->id ?? ''); ?>', this)" class="form-select"
                                    data-live-search="true" tabindex="-1" aria-hidden="true">
                                    <?php
                                        $quote_status = ['draft', 'sent', 'reminder', 'paid-collected', 'paid-delivered', 'collect', 'delivered', 'expired'];
                                    ?>
                                    <option value=""> -- Select Product Type --</option>
                                    <?php $__currentLoopData = $quote_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $select = old('status', $quote->status) == $status ? 'selected' : '';
                                        ?>
                                        <option value="<?php echo e($status); ?>" <?php echo e($select); ?>><?php echo e($status); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <div>
                                    <a href="<?php echo e(route('quote.create', $quote)); ?>" data-toggle="tooltip" title="View Quote">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                
                                    <a href="<?php echo e(route('quote.pdf', $quote->id)); ?>" data-toggle="tooltip" title="Send & Download Quote">
                                        <i class="fa fa-location-arrow"></i>
                                    </a>
                                
                                    <a href="<?php echo e(route('quote_riplicate', $quote)); ?>" data-toggle="tooltip" title="Duplicate Quote">
                                        <i class="fa fa-copy"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
    <script>
        // function quoteStatus(id) {
        //     var selectedValue = $('#quote-status').val();
        //     alert(selectedValue);

        //     // any other code you want to execute based on the selected value
        // }

        function quoteStatus(quoteId, select) {
            var quote_id = quoteId;
            var status = $(select).val();
            $.ajax({
                type: "GET",
                url: " <?php echo e(route('quote_status')); ?>",
                data: {
                    status: status,
                    quote_id: quote_id
                },
                success: function(data) {
                    console.log(data);
                    //console.log(data);
                    // console.log('ok')
                    // location.reload();
                }

            });

        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/components/pages/quote.blade.php ENDPATH**/ ?>