<?php $__env->startSection('title'); ?>
    <title>Customer quote</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="customer py-5">
        <div class="container">
            <table class="table table-bordered nowrap no-footer w-100" id="example">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Client</th>
                        <th>Phone Number</th>
                        <th>Postal Code</th>
                        <th>Added On</th>
                        <th>Total Quote</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($quotes): ?>
                        <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>ROKA-00000<?php echo e($quote->id); ?></td>
                                <td><?php echo e($quote->user->name); ?></td>
                                <td><?php echo e($quote->user->phone); ?></td>
                                <td><?php echo e($quote->user->postal_code); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($quote->created_at))); ?></td>
                                <td>
                                    <?php
                                        $quote_total = $quote->deals->sum('total_gross');
                                    ?>
                                    <?php echo e($quote_total); ?>

                                </td>
                                <td>
                                    <div>
                                        <a href="" data-toggle="tooltip" title="View Quote"><i class="fa fa-eye"></i></a>
                                        <a href="<?php echo e(route('download_pdf', $quote->id)); ?>" data-toggle="tooltip"
                                            title="Send & Download Quote"><i class="fa fa-location-arrow"></i></a>
                                        <a href="" data-toggle="tooltip" title="Duplicate Quote"><i
                                                class="fa fa-copy"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboardlayouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\office project\furniture-spray-business\resources\views/customer/view_customer_quote.blade.php ENDPATH**/ ?>