<div class="product py-5">
    <div class="container">
        <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-primary pull-right">
            <i class="fa fa-plus"></i> Add New Customer
        </a>
        <table class="table table-bordered nowrap no-footer w-100" id="example">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Postal Code</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($datadetail): ?>
                    <?php $__currentLoopData = $datadetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($clients->name); ?></td>
                            <td><?php echo e($clients->email); ?></td>
                            <td><?php echo e($clients->phone); ?></td>
                            <td><?php echo e($clients->postal_code); ?></td>
                            <td><?php echo e($clients->address); ?></td>
                            <td>
                                <div>
                                    <a href="<?php echo e(route('customer.edit', $clients->id)); ?>" data-toggle="tooltip"
                                        title="Edit Customer">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    <a href="<?php echo e(route('quote.show', $clients->id)); ?>" data-toggle="tooltip"
                                        title="View Related Quotes">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH P:\office project\furniture-spray-business\resources\views/components/pages/customer.blade.php ENDPATH**/ ?>